# Bill Tilghman — Version 1

A private, mobile-friendly starting application for a single-owner AI employee.

## What Version 1 does
- Runs a Bill Tilghman agent using the OpenAI Agents SDK.
- Provides a simple web chat interface.
- Persists the primary conversation in SQLite.
- Uses the Bill Tilghman operating charter.
- Has no financial, email, wallet, or marketplace tools.

## Run locally

Requires Python 3.10+.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Put your OPENAI_API_KEY in .env
uvicorn app:app --host 127.0.0.1 --port 8000
```

Then open http://127.0.0.1:8000/

For a cloud deployment, bind the application to the platform-provided port/host as appropriate. Do not expose the app publicly until authentication has been added.

## Security
The API key belongs only on the server. Do not put it in browser JavaScript.
Version 1 does not include authentication. Treat it as a development build until a server-side authentication layer is added.
